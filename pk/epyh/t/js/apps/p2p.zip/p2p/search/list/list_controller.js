﻿define(["app",
    "apps/p2p/search/list/list_view",
    "common/confirm/profile_view",
    "common/innerloading/view",
    "facebook"
], function (Appersonam, View, Confirm, InnerLoading) {
    Appersonam.module("P2pApp.Search.List", function (List, Appersonam, Backbone, Marionette, $, _) {
        List.Controller = {
            listEntities: function (searchedModel, peersCollection, mode) {
                var self = this;
                var listPanel;
                this.peersCollection = peersCollection;
                require(["entities/contact"], function () {
                    self.fbStatus = '';
                    self.Layout = new View.Layout({ model: new Backbone.Model({ searchType: 'favourites', mode: mode }) });
                    self.Layout.on('nav:back', function () {
                        Appersonam.P2pApp.trigger('nav:back', '', 1);
                    });
                    var containerRegion = null;
                    var emptyContactsCollection = Appersonam.request('new:contactslist');
                    self.loadingListView = new InnerLoading.LoadingListView({ hide: true });

                    self.listView = new View.DedicatedContacts({ firstRender: true, collection: emptyContactsCollection, model: new Backbone.Model({ query: '', mode: mode }) });
                    self.listView.on('item:selected', function (model) {
                        searchedModel.set(model.toJSON());
                    });
                    updated = function () {
                        if (!self.listView.collection.get(this.get('id'))) {
                            self.listView.collection.add(this, { silent: true });
                        }
                        else {
                            self.listView.collection.get(this.get('id')).set(this.toJSON(), { silent: true });
                        }
                        self.listView.collection.sort({ silent: true });
                        //evito che la view si renderizzi da sé
                        self.listView.render();//renderizzo la view
                        Appersonam.P2pApp.trigger('nav:back', 'p2p', 1);
                    };
                    self.listView.on('item:edit', function (model) {
                        model.unbind('change');//per scatenare il change una volta sola
                        model.on('change', updated);
                        Appersonam.P2pApp.trigger('edit:contact', model);
                    });
                    self.Layout.on('new:personal', function () {
                        var model = new Backbone.Model();
                        $('#panel_2').on('webkitTransitionEnd', function () {
                            self.Layout.setActive('personal');
                            $('#panel_2').off();
                        });
                        model.on('change', updated);
                        Appersonam.P2pApp.trigger('edit:contact', model);
                    });

                    self.listView.on('new:favourite', function (entity) {//entity fa parte di una lista di entità miste, quindi non ha la url per essere eliminata
                        var newFavouriteEntity = Appersonam.request("new:hypeFriend", entity.toJSON());
                        newFavouriteEntity.unset('imageId');
                        newFavouriteEntity.save(null, {
                            success: function (result) {
                                Appersonam.request("store:favourites");//inizializzo di nuovo i preferiti
                                self.showResult(true, 'Aggiunto ai preferiti con successo', 'Troverai questo contatto nella tua lista dei preferiti',
                                    function () {
                                        self.Layout.removeBlur();
                                        Appersonam.P2pApp.trigger('close:overlay');
                                    });
                            },
                            error: function (result) {
                            }
                        });
                    });

                    self.listView.on('remove:favourite', function (entity) {//entity fa parte di una lista di entità miste, quindi non ha la url per essere eliminata
                        entity.set({ id: entity.get('id').replace('fv-', '') }, { silent: true });
                        var deleteFavourite = Appersonam.request("new:hypeFriend", entity.toJSON());
                        deleteFavourite.destroy({
                            success: function (result) {
                                Appersonam.request("store:favourites");//inizializzo di nuovo i preferiti
                                self.showResult(true, 'Rimosso dai preferiti con successo', 'Questo contatto non è più tra i tuoi preferiti',
                                    function () {
                                        self.listView.collection.remove(entity);
                                        self.Layout.removeBlur();
                                        Appersonam.P2pApp.trigger('close:overlay');
                                    });
                            },
                            error: function (result) {
                            }
                        });
                    });

                    self.listView.on('item:delete', function (entity) {//entity fa parte di una lista di entità miste, quindi non ha la url per essere eliminata
                        var deleteContactEntity = Appersonam.request("edit:personal", entity.toJSON());
                        var confirmModel = new Backbone.Model({
                            title: "Stai per eliminare questo contatto",
                            description: "Questo contatto verrà rimosso dalla tua lista personale.",
                            button: 'Conferma eliminazione',
                            className: 'confirmation-dialog-danger',
                        });
                        var confirmPanel = new Confirm.Profile({
                            model: confirmModel
                        });
                        Appersonam.P2pApp.trigger('show:overlay', confirmPanel);
                        self.Layout.addBlur();
                        confirmPanel.on('cancel', function () {
                            self.Layout.removeBlur();
                            Appersonam.P2pApp.trigger('close:overlay');
                        });
                        confirmPanel.on('confirm', function () {
                            deleteContactEntity.destroy({
                                success: function (result) {
                                    self.listView.collection.remove(entity);
                                    self.Layout.removeBlur();
                                    Appersonam.P2pApp.trigger('close:overlay');
                                },
                                error: function (result) {
                                    self.Layout.removeBlur();
                                    Appersonam.P2pApp.trigger('close:overlay');
                                }
                            });
                        });
                    });
                    self.listView.on("bad:destination", function (value) {
                        self.showResult(false, 'Il recapito ' + value + ' non è valido');
                    });
                    self.listView.on('search', function (query) {
                        self.search(query);
                    });

                    self.listView.on('item:contact:show', function (mateReference, childView) {
                        var data = {
                            subType: 'p2p',
                            mateReference: mateReference
                        }
                        var fetchingImage = Appersonam.request("movement:entity:new", data, false);
                        $.when(fetchingImage).done(function (imgEntity) {
                            childView.model.set({ imageValue: imgEntity.get('image') });
                        });
                    });

                    self.Layout.on('render', function () {
                        self.firstLoading = true;
                        self.searchType = this.model.get('searchType');
                        self.search('');
                    });
                    self.Layout.on('switch', function (searchType) {
                        self.searchType = searchType;
                        self.firstLoading = true;
                        self.listView.collection.reset([], { silent: true });//evito che la view si renderizzi da sé
                        self.listView.firstRender = true;
                        self.listView.render();//renderizzo la view
                        self.search('');
                    });
                    Appersonam.P2pApp.trigger('show:main', self.Layout, 2);
                });
            },
            showResult: function (success, title, message, callBack) {
                var self = this;
                if (success === true) {
                    var confirmModel = new Backbone.Model({
                        title: title,
                        description: message,
                        button: 'OK',
                        className: 'information-dialog',
                        closeButton: 'none'
                    });
                }
                else {
                    var confirmModel = new Backbone.Model({
                        title: 'Si è verificato un errore',
                        description: message,
                        className: 'confirmation-dialog-danger',
                    });
                }
                confirmPanel = new Confirm.Profile({
                    model: confirmModel
                });
                confirmPanel.on("cancel", function () {
                    self.Layout.removeBlur();
                    Appersonam.P2pApp.trigger('close:overlay');
                });
                confirmPanel.on("confirm", function () {
                    self.Layout.removeBlur();
                    if (callBack) {
                        callBack();
                    }
                    else {
                        Appersonam.P2pApp.trigger('close:overlay');
                        Appersonam.P2pApp.trigger('nav:back', "", 1);
                    }
                });
                self.Layout.addBlur();
                Appersonam.P2pApp.trigger('show:overlay', confirmPanel);
            },
            search: function (query) {
                //Appersonam.trigger('show:loading');
                var self = this;
                var updateList = function () {
                    var fetchingContacts = Appersonam.request("search:" + self.searchType, query, self.peersCollection);
                    $.when(fetchingContacts).done(function (contacts) {

                        self.listView.model.set({ query: query });
                        self.listView.collection.reset(contacts.toJSON(), { silent: true });//evito che la view si renderizzi da sé

                        var now = new Date().getTime();
                        console.log("inizio rendering di " + self.listView.collection.length + (now - Appersonam.CommonVariables['logInstant']));
                        Appersonam.CommonVariables['logInstant'] = now;

                        //----- 
                        if (self.firstLoading === true) {
                            self.firstLoading = false;
                            self.loadingListView.disappear();
                            self.Layout.searchRegion.show(self.listView);
                        }
                        else {
                            self.listView.render();//renderizzo la view
                        }
                    });
                };
                if (self.firstLoading === true) {
                    self.Layout.loadingRegion.show(self.loadingListView);
                    self.loadingListView.visualize(updateList);
                }
                else {
                    updateList();
                }
            }
        }
    });
    return Appersonam.P2pApp.Search.List.Controller;
});