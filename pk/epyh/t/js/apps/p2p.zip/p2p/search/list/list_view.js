define(["app",
    'templates',
    "moment",
    /*'Iscroll'*/
], function (Appersonam, JST, moment/*, Iscroll*/) {
    Appersonam.module("P2pApp.Search.List.View", function (View, Appersonam, Backbone, Marionette, $, _, Handlebars) {

        moment.lang('it');
        //var infScroll = Icroll;
        View.Layout = Marionette.Layout.extend({
            template: JST['assets/js/apps/p2p/search/list/templates/layout.html'],
            className: 'contacts-search-panel',
            events: {
                'click .js-back': 'back',
                'click .js-switch': 'switchSearch',
                'click .js-new-contact': 'newContact'
            },
            newContact: function (e) {
                this.trigger('new:personal');
            },
            initialize: function () {
                this.model.on('change', this.render, this);
            },
            addBlur: function () {
                this.$el.addClass('blurred-element');
            },
            removeBlur: function () {
                this.$el.removeClass('blurred-element');
            },
            regions: {
                loadingRegion: '#loading-panel',
                searchRegion: '#search-panel'
            },
            query: '',
            typingTimer: '',

            setActive: function (className) {
                this.$el.find('#bottom-panel .' + className).click();
            },

            switchSearch: function (e) {
                e.preventDefault();
                var searchType = $(e.currentTarget).data('searchtype');
                //this.model.set({ searchType: searchType });
                this.$el.find('.js-switch').removeClass('selected');
                $(e.currentTarget).addClass('selected');
                this.$el.find('#top-panel').removeClass().addClass(searchType);
                this.trigger('switch', searchType);
            },
            back: function (e) {
                e.preventDefault();
                this.trigger('nav:back');
            },
        });

        View.ContactReference = Marionette.ItemView.extend({
            //contatti di ogni possibile destinatario
            template: JST['assets/js/apps/p2p/search/list/templates/contact_reference.html'],
            events: {
                "click": "clicked",
            },
            clicked: function (e) {
                e.preventDefault();
                e.stopPropagation();
                var value = this.model.get('value').replace(/ /g, '');
                this.trigger('clicked', value);
            },
            tagName: 'li',
            className: 'contact-reference-item',

        });

        View.Contact = Marionette.CompositeView.extend({
            //singolo destinatario risultato della ricerca
            template: JST['assets/js/apps/p2p/search/list/templates/contacts_list_item.html'],
            className: 'contacts-item',
            itemView: View.ContactReference,
            itemViewContainer: "ul.contact-reference-list",
            events: {
                'click': 'clicked',
                'click .js-edit': 'editClicked',
                'click .js-delete': 'deleteClicked',
                "click .js-favourite": "newFavourite",
                "click .js-remove-favourite": "removeFavourite"
            },
            editClicked: function (e) {
                e.preventDefault();
                e.stopPropagation();
                this.trigger('edit', this.model);
            },
            deleteClicked: function (e) {
                e.preventDefault();
                e.stopPropagation();
                this.trigger('delete', this.model);
            },
            newFavourite: function (e) {
                e.preventDefault();
                e.stopPropagation();
                this.trigger('new:favourite', this.model);
            },
            removeFavourite: function (e) {
                e.preventDefault();
                e.stopPropagation();
                this.trigger('remove:favourite', this.model);
            },
            onRender: function () {
                if (this.childrenVisible) {
                    this.$el.find('ul.contact-reference-list').slideDown("slow");
                }
            },
            clicked: function (e) {
                e.preventDefault();
                e.stopPropagation();

                var array = new Array();
                var iban = this.model.get('iban');
                var email = this.model.get('email');
                var phoneNumber = this.model.get('phoneNumber');
                array = this.pushInArray(this.model.get('type'), email, phoneNumber, iban, array);
                this.collection = new Backbone.Collection(array);
                var self = this;
                if (this.childrenVisible) {
                    this.$el.find('ul.contact-reference-list').slideUp("slow", function () {
                        self.collection.reset();
                        self.childrenVisible = false;
                        self.render();
                    });
                }
                else {
                    if (this.collection.length > 1 && this.model.get('type') !== 'favourite' && this.model.get('type') !== 'hype') {
                        this.childrenVisible = true;
                        this.render();
                    }
                    else {
                        var value = this.collection.first().get('value').replace(/ /g, '');
                        if (/^[\.\w]+@([a-zA-Z_0-9]+?\.)*[a-zA-Z_0-9]+?\.[a-zA-Z]{2,3}$/.test(value) !== true && this.collection.length > 1) {
                            var value = this.collection.last().get('value').replace(/ /g, '');
                        }
                        var newModel = new Backbone.Model(this.model.toJSON());
                        newModel.set({ destination: value });
                        this.trigger('clicked', newModel);
                    }
                }
            },
            initialize: function () {
                var self = this;
                this.on("itemview:clicked", function (childView, value) {
                    var newModel = new Backbone.Model(self.model.toJSON());
                    newModel.set({ destination: value });
                    self.trigger('clicked', newModel);
                });
                this.model.on("change", function () {
                    this.render();
                }, this);
            },
            pushInArray: function (type, email, phoneNumber, iban, array) {
                if (type === 'personal') {
                    if (email) {
                        /*if (!Array.isArray(email)) {
                            email = new Array(email);
                        } 
                        for (var i = 0; i < email.length; i++) {*/
                        array.push({ value: email/*[i]*/, type: 'email' });
                        /*} */
                    }
                    if (phoneNumber) {
                        /*if (!Array.isArray(phoneNumber)) {
                            phoneNumber = new Array(phoneNumber);
                        }
                        for (var i = 0; i < phoneNumber.length; i++) {*/
                        array.push({ value: phoneNumber/*[i]*/, type: 'phoneNumber' });
                        /*}*/
                    }
                    if (iban) {
                        array.push({ value: iban, type: 'iban' });
                    }
                }
                else {
                    if (phoneNumber) {
                        if (!Array.isArray(phoneNumber)) {
                            phoneNumber = new Array(phoneNumber);
                        }
                        for (var i = 0; i < phoneNumber.length; i++) {
                            array.push({ value: phoneNumber[i], type: 'phoneNumber' });
                        }
                    }
                    if (email) {
                        if (!Array.isArray(email)) {
                            email = new Array(email);
                        }
                        for (var i = 0; i < email.length; i++) {
                            array.push({ value: email[i], type: 'email' });
                        }
                    }
                }
                return array
            },
            onShow: function () {
                if (('' + this.model.get('firstName') + this.model.get('lastName')).length < 1) {
                    this.$el.find('.title-line').html(this.model.get('nickname'));
                }
                /*if (this.model.get('type') === 'hype' || this.model.get('type') === 'favourite') {// serve per prendere le immagini hypose di un contatto 
                    this.trigger('contact:show');
                }*/
            }
        });

        View.Contacts = Marionette.CompositeView.extend({
            //lista di destinatari, risultato di ogni ricerca
            template: JST['assets/js/apps/p2p/search/list/templates/contacts_list.html'],
            className: 'peers-item contacts-container',
            //emptyView: NoEntitiesView,
            itemView: View.Contact,
            itemViewContainer: ".contacts-list",
            buildItemView: function (item, ItemView) {
                var view = new ItemView({
                    model: item,
                    contactsType: this.options.contactsType,
                    mode: this.options.mode
                    //altra roba per caratterizzare una itemview hype rispetto ad una legacy
                });
                return view;
            },
            events: {
                'keyup .js-search': 'keyup',
                'paste .js-search': 'keyup',
                'change .js-search': 'keyup',
                'keydown .js-search': 'keydown',
                'touchstart .contacts-list': 'hideKeyboard',
                'click #js-add-peer.active': 'validatePeerForm',
                'click #js-show-form': 'showForm',
                'click #js-search-peer': 'contactSearch'
            },
            hideKeyboard: function () {
                this.$el.find('.js-search').blur();
            },
            query: '',
            typingTimer: '',
            keydown: function () {
                clearTimeout(this.typingTimer);
            },
            activateAddPeerButton: function () {
                this.$el.find('#js-add-peer').addClass('active');
            },
            deactivateAddPeerButton: function () {
                this.$el.find('#js-add-peer').removeClass('active');
            },
            keyup: function (e) {
                clearTimeout(this.typingTimer);
                var self = this;
                var currentTarget = $(e.currentTarget);
                var value = currentTarget.val();
                isIban = /^[Ii][Tt][0-9]/.test(value.toLowerCase());
                this.$el.find('.info-block > .title-line > span').html(value);
                this.typingTimer = setTimeout(function () {
                    self.firstRender = false;
                    if (value.length >= 3) {
                        if (isIban === true) {
                            self.trigger("iban", currentTarget.val());
                            self.$el.find('.loading-contacts').fadeIn();
                        }
                        else {
                            self.$el.find('.loading-contacts').fadeIn();
                            self.trigger("search", currentTarget.val());
                        }
                    }
                    else if (value.length < 1) {
                        self.model.set('query', '');
                        self.collection.reset();
                        self.$el.find('#js-show-form').hide();
                    }
                }, 700);
            },
            resetView: function () {
                this.model.set({ query: '' });
                this.collection.reset();
                this.$el.find('#search-area').hide();
                if (this.model.get('mode') === 'request') {
                    this.$el.find('#js-add-peer').addClass('active');
                }
            },
            validatePeerForm: function () {
                //valido il form del peer
                this.trigger('validate:peer:form');
            },
            newPeer: function (e) {
                if (e) {
                    e.preventDefault();
                    e.stopPropagation();
                }
                this.model.set({ query: '' });
                this.$el.find('.js-search').val('');
                this.collection.reset();
            },
            contactSearch: function (e) {
                e.preventDefault();
                e.stopPropagation();
                this.trigger('import:contact');
            },
            showForm: function (e, firstName, lastName) {
                if (e) {
                    e.preventDefault();
                    e.stopPropagation();
                }
                this.collection.reset();
                this.trigger('show:form', this.model.get('query'), firstName, lastName);
                this.model.set('query', '');
                this.$el.find('.js-search').val('');
                this.$el.find('#js-show-form').hide();
                this.$el.find('.search-result').hide();
                this.$el.find('#search-area').hide();
            },
            initialize: function () {
                this.firstRender = this.options.firstRender;
                //-----
                var now = new Date();
                console.log("Inizializzo view con elenco contatti:   " + now.getHours() + ":" + now.getMinutes() + ":" + now.getSeconds() + "." + now.getMilliseconds());
                //----- 
                var self = this;
                this.collection.on('reset', function () {
                    self.onRender();
                });
                this.on("itemview:edit", function (childView, model) {
                    this.trigger('edit', model);
                });
                this.on("itemview:delete", function (childView, model) {
                    this.trigger('item:delete', model);
                });
                this.on("itemview:contact:show", function (childView) {
                    var model = childView.model;
                    var mateReference = '';
                    if (model.get('email').length > 0) {
                        mateReference = model.get('email')[0];
                        if (mateReference.length === 0) {
                            mateReference = model.get('phoneNumber')[0];
                        }
                    }
                    else {
                        mateReference = model.get('phoneNumber')[0];
                    }

                    this.trigger('item:contact:show', mateReference, childView);
                });
                this.on("itemview:clicked", function (childView, model) {
                    var destination = model.get('destination');
                    var isIban = IBAN.isValid(destination);
                    var isEmail = /^[\.\w]+@([a-zA-Z_0-9]+?\.)*[a-zA-Z_0-9]+?\.[a-zA-Z]{2,3}$/.test(destination);
                    var isPhoneNumber = /^([00|\+]+\d{2})?3\d{9}$/.test(destination);
                    if ((!isIban || (isIban && this.model.get('mode') === 'request')) && !isEmail && !isPhoneNumber) {
                        this.trigger('bad:destination', destination);
                    }
                    else {
                        this.resetView();
                        this.trigger('item:selected', model);
                    }
                });
            },
            onRender: function () {
                //-----
                var now = new Date().getTime();
                console.log("Finito rendering dei contatti:   " + (now - Appersonam.CommonVariables['logInstant']));
                Appersonam.CommonVariables['logInstant'] = now;

                //----- 
                var query = this.model.get('query');
                this.$el.find('#js-show-form').show();
                this.$el.find('.loading-contacts').hide();
                if (!(this.collection.length === 0)) {
                    // LA collezione non � vuota
                    this.$el.find('.search-result').show();
                    this.$el.find('.search-result-title').show();

                    this.$el.find('.send-to-other-peer .with-result').show();
                    this.$el.find('.send-to-other-peer .no-result').hide();

                    this.$el.find('#search-area').addClass("move-up");
                }
                else {
                    if (query.length < 1) {
                        this.$el.find('.search-result').hide();
                        this.$el.find('#search-area').removeClass("move-up");
                    }
                    else {
                        this.$el.find('.search-result').show();
                        this.$el.find('#search-area').addClass("move-up");
                    }
                    this.$el.find('.search-result-title').hide();

                    this.$el.find('.send-to-other-peer .with-result').hide();
                    this.$el.find('.send-to-other-peer .no-result').show();
                }

                var input = this.$el.find('.js-search');
                if (!(this.firstRender === true)) {
                    input.blur();
                    input.focus();
                }
                var tmpStr = input.val();
                input.val('');
                input.val(tmpStr);
                this.$el.find('#search-area').show();
                this.deactivateAddPeerButton();
            },

            onShow: function () {
                this.$el.find('.list-block-title').html(this.options.title);
            },
        });

        View.DedicatedContacts = View.Contacts.extend({
            template: JST['assets/js/apps/p2p/search/list/templates/dedicated_contacts_list.html'],
            initialize: function () {
                this.firstRender = this.options.firstRender;
                //-----
                var now = new Date();
                console.log("Inizializzo view con elenco contatti:   " + now.getHours() + ":" + now.getMinutes() + ":" + now.getSeconds() + "." + now.getMilliseconds());
                //----- 
                //questa composite ha gi� un'azione di render collegata al reset della collezione, anche se non 
                //esplicitamente dichiarato. Non ne ho compreso il motivo

                var self = this;

                this.on("itemview:edit", function (childView, model) {
                    this.trigger('item:edit', model);
                });
                this.on("itemview:delete", function (childView, model) {
                    this.trigger('item:delete', model);
                });
                this.on('itemview:new:favourite', function (childView, model) {
                    self.trigger('new:favourite', model);
                });
                this.on('itemview:remove:favourite', function (childView, model) {
                    self.trigger('remove:favourite', model);
                });
                this.on("itemview:contact:show", function (childView) {
                    var model = childView.model;
                    var mateReference = '';
                    if (model.get('email') && model.get('email').length > 0) {
                        if (model.get('type') !== 'favourite') {
                            mateReference = model.get('email')[0];
                        }
                        else {
                            mateReference = model.get('email');
                        }
                    }
                    else {
                        if (model.get('type') !== 'favourite') {
                            mateReference = model.get('phoneNumber')[0];
                        }
                        else {
                            mateReference = model.get('phoneNumber');
                        }
                    }
                    this.trigger('item:contact:show', mateReference, childView);
                });
                this.on("itemview:clicked", function (childView, model) {
                    var destination = model.get('destination');
                    var isIban = IBAN.isValid(destination);
                    var isEmail = /^[\.\w]+@([a-zA-Z_0-9]+?\.)*[a-zA-Z_0-9]+?\.[a-zA-Z]{2,3}$/.test(destination);
                    var isPhoneNumber = /^([00|\+]+\d{2})?3\d{9}$/.test(destination);
                    if ((!isIban || (isIban && this.model.get('mode') === 'request')) && !isEmail && !isPhoneNumber) {
                        self.trigger('bad:destination', destination);
                    }
                    else {
                        self.trigger('item:selected', model);
                    }
                });
            },
            keyup: function (e) {
                clearTimeout(this.typingTimer);
                var self = this;
                var currentTarget = $(e.currentTarget);
                var value = currentTarget.val();
                this.typingTimer = setTimeout(function () {
                    self.firstRender = false;
                    if (value.length >= 3 || value.length < 1) {
                        self.$el.find('.loading-contacts').fadeIn();
                        self.trigger("search", currentTarget.val());
                    }
                }, 1700);
            }
        });

        View.NoEntitiesView = Marionette.ItemView.extend({
            template: JST['assets/js/apps/p2p/search/list/templates/none.html'],
        });

    }, Handlebars);
    return Appersonam.P2pApp.Search.List.View;
});