﻿define(["app",
    "common/authorize/profile_view",
    "common/keyboard/view",
    "apps/p2p/hypeTransfer/profile_view",
    "apps/p2p/search/list/list_view",
    "common/confirm/profile_view",
    "iban"
], function (Appersonam, Authorize, Keyboard, FormView, SearchView, Confirm) {
    Appersonam.module("P2pApp.HypeTransfer", function (HypeTransfer, Appersonam, Backbone, Marionette, $, _) {
        HypeTransfer.Controller = {
            profile: function (mode) {
                var self = this;
                self.peerFormOpen = false;
                self.searchLocked = false;
                require(["entities/p2p", "entities/movement", "entities/contact", "entities/user", 'entities/authorization', 'entities/financialSituation', "entities/file"], function () {

                    var fetchingUserImage = Appersonam.request("get:image", Appersonam.CommonVariables['myself'].image, '', false);
                    $.when(fetchingUserImage).done(function (userImgEntity) {
                        self.userImgEntity = userImgEntity;
                    });
                    self.peersCollection = new Backbone.Collection();
                    try {
                        self.transferView = new FormView.Form({ model: new Backbone.Model({ mode: mode, sts: Appersonam.CommonVariables['spendable'] }) });
                    }
                    catch (exception) {
                        alert(exception.stack);
                    }
                    var peersView = new FormView.PeersList({ collection: new Backbone.Collection(), model: new Backbone.Model({ mode: mode }) });
                    var contactsView = new SearchView.Contacts({ firstRender: true, collection: new Backbone.Collection(), model: new Backbone.Model({ query: '', mode: mode }) });
                    contactsView.on('search', function (query) {
                        if (self.searchLocked !== true) {
                            var fetchingContacts = Appersonam.request("search:all", query, self.peersCollection);
                            peersView.hideForm();
                            $.when(fetchingContacts).done(function (contacts) {
                                if (self.searchLocked !== true) {
                                    contactsView.model.set({ query: query });
                                    contactsView.collection.reset(contacts.toJSON());
                                }
                            });
                        }
                    });

                    contactsView.on('item:contact:show', function (mateReference, childView) {
                        var data = {
                            subType: 'p2p',
                            mateReference: mateReference
                        }
                        var fetchingImage = Appersonam.request("movement:entity:new", data, false);
                        $.when(fetchingImage).done(function (imgEntity) {
                            childView.model.set({ imageValue: imgEntity.get('image') });
                        });
                    });

                    contactsView.on('iban', function (query) {
                        contactsView.model.set({ query: query });
                        contactsView.collection.reset();
                    });

                    self.searchContactModel = new Backbone.Model();
                    self.searchContactModel.on('change', function () {//dalla view dedicata alla ricerca
                        contactsView.resetView();
                        if (IBAN.isValid(this.get('destination'))) {
                            peersView.showForm(this.get('destination'), this.get('firstName'), this.get('lastName'));
                            self.peerFormOpen = true;
                        }
                        else {
                            peersView.setPeer(this);
                            if (mode === 'request') {
                                contactsView.activateAddPeerButton();
                            }
                        }
                        Appersonam.P2pApp.trigger('nav:back', 'p2p', 1);
                    });

                    contactsView.on('import:contact', function () {//apre la rubrica
                        self.searchContactModel.set({ id: null }, { silent: true });
                        Appersonam.P2pApp.trigger('p2p:search', self.searchContactModel, self.peersCollection, this.model.get('mode'));
                    });

                    peersView.on('update:collection', function (collection, actionType) {
                        self.transferView.datesRegion.close();
                        self.peersCollection = collection;
                        if (collection.length < 1) {
                            contactsView.newPeer();
                        }
                        else {
                            self.transferView.removeError('peer');
                        }
                        if (actionType === 'add') {
                            self.searchLocked = true;
                        }
                        else {
                            self.searchLocked = false;
                        }
                        self.transferView.setAmount(null, self.peersCollection.length);
                    });
                    contactsView.on('validate:peer:form', function () {
                        if (self.peerFormOpen) {//devo validare il form
                            peersView.addPeerToList();
                        }
                        else {//abilito la ricerca per aggiungere un nuovo peer
                            contactsView.newPeer();
                            self.searchLocked = false;
                        }
                    });
                    peersView.on('validate:peer:form', function (data) {
                        if (data.destination.length > 0 && data.firstName.length > 0 && data.lastName.length > 0) {
                            //attivare il tasto per aggiungere un altro peer
                            contactsView.activateAddPeerButton();
                        }
                        else {
                            contactsView.deactivateAddPeerButton();
                        }
                    });
                    peersView.on('submit:peer:form', function (data, isIban) {
                        self.transferMode = false;
                        var newPeer = Appersonam.request("new:peer");
                        var errors = newPeer.validate(data, mode);
                        if (errors) {
                            peersView.triggerMethod("form:data:invalid", errors, '');
                        }
                        else {
                            var createPeer = function () {
                                self.peerFormOpen = false;
                                contactsView.resetView();
                                newPeer.set(data);
                                newPeer.set({ id: 'nw-' + (self.peersCollection.length + 1) });
                                peersView.setPeer(newPeer);
                                if (mode === 'request') {
                                    contactsView.newPeer();
                                    self.searchLocked = false;
                                }
                                else if (self.transferMode === true) {
                                    self.completeTransfer(data);
                                    self.transferData = data;// MI SALVO I DATI DEL BONIFICO NEL CASO VENGA MODIFICATO DOPO LA SCHERMATA DI RIEPILOGO
                                }
                            }
                            //validare eventuale iban e data
                            if (isIban) {
                                //ovviamente mi tocca validare anche il form esterno
                                var externalViewData = self.transferView.getData();
                                var externalViewErrors = Appersonam.request("p2p:payment", externalViewData, null).errors;
                                delete externalViewErrors.peer;
                                if (!$.isEmptyObject(externalViewErrors)) {
                                    self.transferView.triggerMethod("form:data:invalid", externalViewErrors);
                                }
                                else {
                                    data.amount = externalViewData.amount;
                                    data.description = externalViewData.description;
                                    var fetchingIbanValidation = Appersonam.request("validate:transfer", data, Appersonam.CommonVariables['myself'].aliasIb);
                                    $.when(fetchingIbanValidation).done(function (result) {
                                        if (result.errors) {
                                            peersView.triggerMethod("form:data:invalid", result.errors, '');
                                        }
                                        else {
                                            self.transferMode = true;//ho preparato un bonifico 
                                            createPeer();
                                        }
                                    });
                                }
                            }
                            else {
                                createPeer();
                            }
                        }
                    });
                    contactsView.on('show:form', function (query, firstName, lastName) {
                        self.transferView.removeError('peer');
                        self.peerFormOpen = true;
                        self.searchLocked = true;
                        peersView.showForm(query, firstName, lastName);
                    });
                    peersView.on('close:form', function () {
                        self.peerFormOpen = false;
                        self.searchLocked = false;
                        contactsView.newPeer();
                    });
                    contactsView.on('item:selected', function (item) {
                        if (IBAN.isValid(item.get('destination'))) {
                            peersView.showForm(item.get('destination'), item.get('firstName'), item.get('lastName'));
                            self.peerFormOpen = true;
                        }
                        else {
                            peersView.setPeer(item);
                            if (mode === 'request') {
                                contactsView.activateAddPeerButton();
                            }
                        }
                    });
                    contactsView.on("bad:destination", function (value) {
                        self.showResult(false, 'Il recapito ' + value + ' non è valido');
                    });
                    self.transferView.on('show', function () {
                        this.peersRegion.show(peersView);//this in questo contesto è transferView
                        this.contactsRegion.show(contactsView);
                    });
                    self.transferView.on('corner:menu', function () {
                        Appersonam.NavigationApp.trigger('corner:menu');
                    });
                    self.transferView.on("keyboard:show", function (value) {
                        var keyboard = new Keyboard.KeyboardWidget({ value: value });
                        self.transferView.keyboardRegion.show(keyboard);
                        keyboard.on("keyboard:value:changed", function (data) {

                            self.transferView.setAmount(data, self.peersCollection.length);
                            if (parseFloat(data) >= 0.01 && parseInt(data) !== Infinity) {
                                self.transferView.removeError('amount');
                            }
                        });
                        keyboard.on("keyboard:close", function (data) {
                            try {
                                var value = self.transferView.amount;
                                if (parseFloat(value) >= 0.01 && parseInt(value) !== Infinity) {
                                    self.transferView.keyboardRegion.close();
                                }
                            }
                            catch (ex) {

                            }
                        });
                    });
                    self.transferView.on("keyboard:close", function (data) {
                        try {
                            var value = self.transferView.amount;
                            if (parseFloat(value) >= 0.01 && parseInt(value) !== Infinity) {
                                self.transferView.keyboardRegion.close();
                            }
                        }
                        catch (ex) {

                        }
                    });
                    self.transferView.on("form:submit", function (formData) {
                        if (self.peerFormOpen) {
                            peersView.addPeerToList();
                        }
                        formData.amount = Math.round((formData.amount / self.peersCollection.length) * 100) / 100;
                        formData.instrumentValue = Appersonam.CommonVariables['myself'].idConto;
                        self.aliasIb = Appersonam.CommonVariables['myself'].aliasIb;
                        if (mode === 'payment') {
                            var transferObject = Appersonam.request("p2p:payment", formData, self.peersCollection.first());
                        }
                        else {
                            var transferObject = Appersonam.request("p2p:request", formData, self.peersCollection);
                        }
                        var errors = transferObject.errors;
                        if ($.isEmptyObject(errors)) {
                            if (transferObject.type === 'transfer') {
                                self.transferData.amount = formData.amount;
                                self.transferData.description = formData.description;
                                //DEVO RIFARE LA SETBONIFICOINIT, NEL CASO SIANO CAMBIATI DESCRIZIONE O AMMONTARE
                                Appersonam.request("validate:transfer", self.transferData, Appersonam.CommonVariables['myself'].aliasIb);

                                self.completeTransfer(self.transferData);
                            }
                            else {
                                self.transferMode = false;
                                self.transferView.datesRegion.close();
                                self.submitData(transferObject.model, mode);
                            }
                        }
                        else {
                            self.transferView.triggerMethod("form:data:invalid", errors);
                            if (self.peerFormOpen) {
                                self.transferView.removeError('peer');
                            }
                        }
                    });
                    Appersonam.P2pApp.trigger('show:main', self.transferView, 1);
                });
            },
            transferCheckDates: function (data, transferDates) {
                var self = this;
                var datesModel = Appersonam.request("transfer:dates", transferDates);
                self.datesView = new FormView.TransferDates({ model: datesModel });
                self.datesView.destination = data.destination;
                self.transferView.datesRegion.show(self.datesView);
                self.datesView.bind('date:submit', function (chosenDate, transferData) {
                    transferData.date = chosenDate;
                    self.completeTransfer(transferData);
                });
            },

            transferPayment: function (data) {
                var self = this;
                var fetchingTransferDates = Appersonam.request("p2p:transfer:dates", data.destination);
                $.when(fetchingTransferDates).done(function (transferDates) {
                    ErrorMessage = transferDates.ErrorMessage;
                    if (ErrorMessage) {
                        self.showResult(false, 'Ricontrollare i dati inseriti.');
                        return false;
                    }
                    else {
                        self.transferCheckDates(data, transferDates);
                    }
                });
            },

            completeTransfer: function (data) {
                var self = this;
                var completeTransferObject = Appersonam.request("p2p:transfer:model", data, self.aliasIb);
                self.submitData(completeTransferObject, 'transfer');
                /*
                var fetchingTransferValidation = Appersonam.request("p2p:transfer:validation", data, self.aliasIb);
                $.when(fetchingTransferValidation).done(function (transferValidation) {
                    ErrorMessage = transferValidation.ErrorMessage;
                    if (ErrorMessage) {
                        self.showResult(false, 'Ricontrollare i dati inseriti.');
                        return false;
                    } else {
                        var transferModel = Appersonam.request("p2p:transfer:model", data);
                        setTimeout(function () {
                            self.submitData(transferModel, 'transfer');
                        }, 1000);
                    }
                });
                */
            },

            submitData: function (transferModel, mode) {
                var self = this;
                var userImgValue = null;
                if (self.userImgEntity) {
                    userImgValue = self.userImgEntity.get('content');
                }
                var resumeModel = new Backbone.Model({
                    mode: mode,
                    myself: Appersonam.CommonVariables['myself'],
                    amount: transferModel.get('amount'),
                    message: transferModel.get('description'),
                    userImgValue: userImgValue
                });
                var resumeView = new FormView.Resume({ model: resumeModel, collection: self.peersCollection });
                self.transferMode = false;
                resumeView.on('cancel', function () {
                    Appersonam.P2pApp.trigger('close:overlay', '-resume');
                });
                resumeView.on('confirm', function () {
                    var transferModelData = transferModel.toJSON();
                    transferModel.save(null, {
                        data: {
                            amount: transferModel.get('amount')
                        },
                        success: function (result) {
                            if (mode === 'request') {
                                //richiedo via P2P
                                var destinations = transferModel.get('senderAliasesType').senderAliasType;
                                var success = null;
                                if (result.get('Status').code === 'OK') {
                                    success = true;
                                } else {
                                    success = false;
                                }
                                var TransactionDetail = result.get('TransactionDetail');
                                var errorString = '';
                                if (TransactionDetail.length < 1) {
                                    errorString = 'La transazione non è andata a buon fine, ricontrollare i dati inseriti.';
                                } else {
                                    errorString = 'Si è verificato un problema con i seguenti destinatari:';
                                }
                                var successString = 'Transazione eseguita con successo';
                                for (var j = 0; j < TransactionDetail.length; j++) {
                                    var item = TransactionDetail[j].status;
                                    if (!(item.code === 'REQUESTED_OK')) {
                                        success = false;
                                        errorString += ' ' + destinations[j].aliasValue;
                                    }
                                }
                                if (success === true) {
                                    self.showResult(true, "L'utente riceverà la richiesta al più presto");
                                } else {
                                    transferModel.clear();
                                    transferModel.set(transferModelData, { silent: true });
                                    self.showResult(false, errorString);
                                }
                            } else {
                                var ErrorMessage = result.get('ErrorMessage');
                                if (!ErrorMessage) {
                                    if (mode === 'transfer') {
                                        //ok da bonifico
                                        self.showResult(true, "L'utente riceverà l'importo al più presto");
                                    } else { //risposta da p2p
                                        var status = result.get('status');
                                        if (status.code === 'OK') {
                                            //ok p2p
                                            self.showResult(true, "L'utente riceverà l'importo al più presto");
                                        } else {
                                            //fail p2p
                                            transferModel.clear();
                                            transferModel.set(transferModelData, { silent: true });
                                            self.showResult(false, status.description);
                                        }
                                    }
                                } else {
                                    //serve autorizzazione o errore bonifico
                                    var errorCode = ErrorMessage[0].errorCode;
                                    transferModel.unset('ErrorMessage');
                                    self.authorize(errorCode, transferModel, mode);
                                }
                            }
                        },
                        error: function (data) {
                            transferModel.clear();
                            transferModel.set(transferModelData, { silent: true });
                        }
                    });
                });

                Appersonam.P2pApp.trigger('show:overlay', resumeView, '-resume');


            },
            showResult: function (success, message) {
                var self = this;
                if (success === true) {
                    var confirmModel = new Backbone.Model({
                        header: 'Grande!',
                        title: 'Transazione eseguita con successo',
                        description: "L'utente riceverà il denaro nel giro di pochi minuti",
                        button: 'Torna ai movimenti',
                        className: 'receipt-dialog',
                        closeButton: 'none'
                    });
                }
                else {
                    var confirmModel = new Backbone.Model({
                        title: 'Si è verificato un errore',
                        description: message,
                        className: 'confirmation-dialog-danger',
                    });
                }
                confirmPanel = new Confirm.Profile({
                    model: confirmModel
                });
                confirmPanel.on("cancel", function () {
                    self.transferView.removeBlur();
                    Appersonam.P2pApp.trigger('close:overlay');
                });
                confirmPanel.on("confirm", function () {
                    self.returnToMain();
                });
                self.transferView.addBlur();
                Appersonam.P2pApp.trigger('show:overlay', confirmPanel);
                Appersonam.P2pApp.trigger('panelManager:onBackFunction', self.returnToMain);
            },

            returnToMain: function () {
                Appersonam.trigger('reset:loading');
                Appersonam.trigger('show:loading');
                setTimeout(function () {
                    $('.blurred-element').removeClass('blurred-element');
                    Appersonam.P2pApp.trigger('close:overlay');
                    self.userImgEntity = undefined;//rimuovo dalla memoria l'immagine utente
                    Appersonam.trigger('activities', 'movements:list', true);
                    Appersonam.NavigationApp.trigger('set:selected', 'movements', 1);
                }, 600);
            },


            authorize: function (errorCode, transferModel, mode) {
                var self = this;
                var authorizationModel;
                switch (errorCode) {
                    case "690":
                        authorizationModel = Appersonam.request("authorization:entity", true, false); //solo pin
                        break;
                    case "691":
                        authorizationModel = Appersonam.request("authorization:entity", false, true); //solo pwd
                        break;
                    case "692":
                        authorizationModel = Appersonam.request("authorization:entity", true, true); //pin e pwd
                        break;
                    default:
                        self.showResult(false, self.errorCodesMap['000']);
                        return false;
                        break;
                }
                var pinView = new Authorize.Pin({
                    model: authorizationModel
                });
                pinView.on('close', function (data) {
                    self.transferView.removeBlur();
                    Appersonam.P2pApp.trigger('close:overlay', '-pin');
                });
                pinView.on('form:submit', function (data) {
                    data.amount = transferModel.get('amount');
                    var transferModelData = transferModel.toJSON();
                    transferModel.save(null, {
                        data: data,
                        success: function (result) {
                            var ErrorMessage = result.get('ErrorMessage');
                            if (ErrorMessage) {
                                //errore auth
                                var authError = ErrorMessage[0].errorCode;
                                if (authError === '694' || authError === '693') {
                                    //pin o pwd non corretti
                                    if (authorizationModel.get('password') === true) {
                                        //se richiesta anche la password, l'errore riguarda pin o password
                                        authError = '694';
                                    }
                                    self.showResult(false, self.errorCodesMap[authError]);
                                    transferModel.clear();
                                    transferModel.set(transferModelData, { silent: true });
                                    pinView.close();
                                } else {
                                    //errore bonifico
                                    self.showResult(false, self.errorCodesMap['000']);
                                    transferModel.clear();
                                    transferModel.set(transferModelData, { silent: true });
                                    pinView.close();
                                }
                            } else {
                                if (mode === 'transfer') {
                                    //nessun errore bonifico
                                    self.showResult(true);
                                    pinView.close();

                                } else {
                                    //risposta da p2p
                                    var status = result.get('status');
                                    if (status.code === 'OK') {
                                        self.showResult(true);
                                        pinView.close();

                                    } else {

                                        self.showResult(status.description);
                                        pinView.close();
                                    }
                                }
                            }
                        },
                        error: function (data) {
                            transferModel.clear();
                            transferModel.set(transferModelData, { silent: true });
                            pinView.close();
                        }
                    });
                });
                self.transferView.addBlur();
                Appersonam.P2pApp.trigger('show:overlay', pinView, '-pin');
            },
            errorCodesMap: {
                '693': 'Il pin inserito non è valido',
                '694': 'Il pin o la password inseriti non sono validi',
                '000': 'Si è verificato un errore tecnico. Riprovare più tardi.'
            }
        };
    });
    return Appersonam.P2pApp.HypeTransfer.Controller;
});