﻿define(["app", 'templates', "backbone.syphon"],
       function (Appersonam, JST, moment, pickadate, pickerDate, pickerLng) {
           Appersonam.module("P2pApp.Contacts.Profile.View", function (View, Appersonam, Backbone, Marionette, $, _, Handlebars) {
               View.Form = Marionette.Layout.extend({
                   template: JST['assets/js/apps/p2p/contacts/profile/templates/profile.html'],
                   className: 'transfer-form',
                   regions: {
                       formRegion: "#form-region",
                       commandRegion: "#command-region",
                       emailsRegion: '.emails',
                       phonesRegion: '.phones'
                   },
                   className: 'contact-profile-panel',
                   events: {
                       "click .js-submit": "submitClicked",
                       "click .back": "back",
                       'click a.addEmail': 'addEmail',
                       'click a.addPhone': 'addPhone',
                       'keydown input': 'keyDownInput'
                   },
                   keyDownInput: function (e) {
                       var keyCode = e.keyCode;
                       if (keyCode === 13) {
                           e.preventDefault();
                           this.submitClicked(e);
                       }
                   },
                   append: function (className, view, index) {
                       this.$el.find('.' + className).append('<section id="' + className + '_' + index + '"></section>');
                       this.addRegion(className + '_' + index, '#' + className + '_' + index);
                       var region = this.regionManager.get(className + '_' + index);
                       region.show(view);
                   },
                   emails: new Array(),
                   phones: new Array(),
                   addEmail: function (e) {
                       e.preventDefault();
                       emails.push('');
                       this.trigger('email:add', 'email', (emails.length - 1), 'text', '', 'inserisci email');
                   },
                   addPhone: function (e) {
                       e.preventDefault();
                       phones.push('');
                       this.trigger('phone:add', 'phone', (phones.length - 1), 'number', '', 'inserisci numero di telefono');
                   },
                   setValue: function (value, target, index) {
                       if (target === 'email') {
                           emails[index] = value;
                       }
                       else {
                           phones[index] = value;
                       }
                   },
                   back: function (e) {
                       e.preventDefault();
                       e.stopPropagation();
                       this.trigger('back');
                   },
                   onShow: function () {
                       var self = this;
                       Backbone.Syphon.deserialize(this, this.model.toJSON());
                       //if (this.model.get('email')) {
                       //    emails = this.model.get('email').split(',');
                       //    for (var i = 0; i < emails.length; i++) {
                       //        this.trigger('email:add', 'email', i, 'text', emails[i], 'inserisci email');
                       //    }
                       //}
                       //if (this.model.get('phoneNumber')) {
                       //    phones = this.model.get('phoneNumber').split(',');
                       //    for (var i = 0; i < phones.length; i++) {
                       //        this.trigger('phone:add', 'phone', i, 'number', phones[i], 'inserisci numero di telefono');
                       //    }
                       //}
                   },
                   submitClicked: function (e) {
                       e.preventDefault();
                       this.$el.find(".help-inline.error").each(function () {
                           $(this).remove();
                       });
                       var data = Backbone.Syphon.serialize(this);
                       var self = this;
                       this.trigger("form:submit", data);


                       //var emailString = '', phoneString = '';
                       //for (var i = 0; i < emails.length; i++) {
                       //    if (emails[i] !== '') {
                       //        emailString += emails[i];
                       //        if (i + 1 < emails.length) {
                       //            emailString += ',';
                       //        }
                       //    }
                       //}
                       //for (var i = 0; i < phones.length; i++) {
                       //    if (phones[i] !== '') {
                       //        phoneString += phones[i];
                       //        if (i + 1 < phones.length) {
                       //            phoneString += ',';
                       //        }
                       //    }
                       //}
                       //data.email = emailString;
                       //data.phoneNumber = phoneString;
                       //delete data.undefined_submit;
                   },
                   clearFormErrors: function () {
                       var $form = this.$el.find("form");
                       $form.find(".help-inline.error").each(function () {
                           $(this).remove();
                       });
                       this.$el.find('.destination-error').html('');
                   },
                   onFormDataInvalid: function (errors) {
                       var $view = this.$el;
                       var markErrors = function (value, key) {
                           if (value.type === 'destination') {
                               $view.find('.destination-error').html(value.text);
                           }
                           else {
                               var $validatedInput = $view.find('[name="' + key + '"]');
                               var $errorEl = $("<span>", {
                                   class: "help-inline error",
                                   text: value
                               });
                               $validatedInput.after($errorEl).addClass("error");
                           }
                       }
                       this.clearFormErrors();
                       _.each(errors, markErrors);
                   }
               });
           }, Handlebars);
           return Appersonam.P2pApp.Contacts.Profile.View;
       });
