﻿define(["app",
    "apps/p2p/contacts/profile/profile_view",
    "common/input/view"], function (Appersonam, View, Input) {
        Appersonam.module("P2pApp.Contacts.Profile", function (Profile, Appersonam, Backbone, Marionette, $, _) {
            Profile.Controller = {
                newEntity: function () {
                    require(["entities/contact"], function () {
                        var view;
                        var self = this;
                        var inputEmailViews = new Array();
                        var inputPhoneViews = new Array();
                        self.inputViews = new Array();
                        self.inputViews['email'] = inputEmailViews;
                        self.inputViews['phone'] = inputPhoneViews;
                        var newEntity = Appersonam.request("legacy:contact:new");
                        view = new View.Form({
                            model: newEntity,
                        });

                        view.on("back", function () {
                            Appersonam.P2pApp.trigger('nav:back', 'p2p', 1);
                        });
                        view.on("form:submit", function (data) {
                            newEntity.set(data, { silent: true });
                            var saveResult = newEntity.save(null, {
                                serviceDestination: 'NEW',
                                success: function (result) {
                                    Appersonam.P2pApp.trigger('contacts:child:list', result, 1);
                                },
                                error: function (result) { }
                            });
                            if (saveResult === false) {
                                view.triggerMethod("form:data:invalid", newEntity.validationError);
                            }
                        });
                        var addInput = function (self, target, index, type, value, placeholder, view) {
                            self.inputViews[target].push(new Input.InputWidget({
                                model: new Backbone.Model({
                                    name: '',
                                    target: target,
                                    type: type,
                                    placeholder: placeholder,
                                    value: value,
                                    confirmButon: false,
                                    deleteButon: true,
                                    instant: true,
                                    style: 1,
                                })
                            }
                            ));
                            self.inputViews[target][index].on('confirm', function (value, target) {
                                view.setValue(value, target, index);
                            });
                            self.inputViews[target][index].on('delete', function () {
                                view.setValue('', target, index);
                            });
                            view.append(target, self.inputViews[target][index], index);
                        };
                        view.on("email:add", function (target, index, type, value, placeholder) {
                            addInput(self, target, index, type, value, placeholder, view);
                        });

                        view.on("phone:add", function (target, index, type, value, placeholder) {
                            addInput(self, target, index, type, value, placeholder, view);
                        });
                        Appersonam.P2pApp.trigger('show:main', view, 2);
                    });
                },
                editEntity: function (entity) {
                    var self = this;
                    var formEntity = Appersonam.request("edit:personal", entity.toJSON());
                    var inputEmailViews = new Array();
                    var inputPhoneViews = new Array();
                    self.inputViews = new Array();
                    self.inputViews['email'] = inputEmailViews;
                    self.inputViews['phone'] = inputPhoneViews;
                    var view;
                    view = new View.Form({
                        model: formEntity
                    });
                    var addInput = function (self, target, index, type, value, placeholder, view) {//funzione necessaria per aggiungere più email o numeri di telefono, per ora non usata
                        self.inputViews[target].push(new Input.InputWidget({
                            model: new Backbone.Model({
                                name: '',
                                target: target,
                                type: type,
                                placeholder: placeholder,
                                value: value,
                                confirmButon: false,
                                deleteButon: true,
                                instant: true,
                                style: 1,
                            })
                        }
                        ));
                        self.inputViews[target][index].on('confirm', function (value, target) {
                            view.setValue(value, target, index);
                        });
                        self.inputViews[target][index].on('delete', function () {
                            view.setValue('', target, index);
                        });
                        view.append(target, self.inputViews[target][index], index);
                    };
                    view.on("email:add", function (target, index, type, value, placeholder) {
                        addInput(self, target, index, type, value, placeholder, view);
                    });

                    view.on("phone:add", function (target, index, type, value, placeholder) {
                        addInput(self, target, index, type, value, placeholder, view);
                    });

                    view.on("back", function () {
                        Appersonam.P2pApp.trigger('nav:back', 'p2p', 1);
                    });

                    view.on("form:submit", function (data) {
                        var saveResult = formEntity.save(data, {
                            serviceDestination: 'NEW',
                            success: function (result) {
                                data.type = 'personal';
                                data.id = result.get('id');
                                entity.clear({ silent: true });
                                entity.set(data, { silent: false });
                            },
                            error: function (result) { }
                        });
                        if (saveResult === false) {
                            view.triggerMethod("form:data:invalid", formEntity.validationError);
                        }
                    });
                    Appersonam.P2pApp.trigger('show:main', view, 3);
                },

            };
        });

        return Appersonam.P2pApp.Contacts.Profile.Controller;
    });
