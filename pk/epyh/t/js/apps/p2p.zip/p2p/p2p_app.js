﻿define(["app"], function (Appersonam) {
    Appersonam.module("P2pApp", function (P2pApp, Appersonam, Backbone, Marionette, $, _) {

        P2pApp.startWithParent = false;

        P2pApp.onStart = function () { };

        P2pApp.onStop = function () {
            Appersonam.P2pApp.trigger('unset:panelmanager');
        };
    });
    Appersonam.module("Routers.P2pApp", function (P2pAppRouter, Appersonam, Backbone, Marionette, $, _) {
        var activitiesController, transferController;
        var self = this;
        P2pAppRouter.Router = Marionette.AppRouter.extend({
            appRoutes: {
                //"p2p/payment": "paymentNavigation",
                //"p2p/request": "requestNavigation",
                //"p2p/simplePayment": "simplePayment",
                //"p2p/simpleRequest": "simpleRequest",
                //"p2p/hypePayment": "hypePayment",
                //"p2p/hypeRequest": "hypeRequest"
            }
        });

        var API = {
            navigation: function () {
                require(["apps/p2p/menu/menu_controller"], function (controller) {
                    activitiesController = controller;
                    //if (!self.panelManager) {
                    Appersonam.startSubApp("P2pApp");
                    require(["common/panel/panel_manager"], function (PanelManager) {
                        self.panelManager = new PanelManager.Panels();
                        if (self.disableMenu !== true) {
                            Appersonam.NavigationApp.trigger('toggle:menu');
                        }
                        setTimeout(function () {
                            Appersonam.mainContentRegion.show(self.panelManager);
                            activitiesController.navigation(self.mode);
                        }, 300);
                    });
                    /*}
                    else {
                        activitiesController.navigation(self.mode);
                    }*/
                });
            },
            newHypeTransfer: function (mode) {
                require(["apps/p2p/hypeTransfer/profile_controller"], function (controller) {
                    transferController = controller;
                    //if (!self.panelManager) {
                    Appersonam.startSubApp("P2pApp");
                    require(["common/panel/panel_manager"], function (PanelManager) {
                        self.panelManager = new PanelManager.Panels();
                        if (self.disableMenu !== true) {
                            Appersonam.NavigationApp.trigger('toggle:menu');
                        }
                        setTimeout(function () {
                            Appersonam.mainContentRegion.show(self.panelManager);
                            transferController.profile(mode);
                        }, 300);
                    });
                    /*}
                    else {
                        activitiesController.navigation(self.mode);
                    }*/
                }); 
            },
            paymentNavigation: function () {
                self.mode = 'payment';
                API.navigation();
            },
            requestNavigation: function () {
                self.mode = 'request';
                API.navigation();
            },
            simpleTransfer: function (object, hype) {
                require(["apps/p2p/simpleTransfer/profile_controller"], function (controller) {
                    controller.profile(self.mode, 2, object, hype);
                });
            },
            simplePayment: function (model, hype) {
                self.mode = 'payment';
                API.simpleTransfer(model, hype);
            },
            simpleRequest: function (object, hype) {
                self.mode = 'request';
                API.simpleTransfer(object, hype);
            },
            hypeTransfer: function (object) {
                require(["apps/p2p/hypeTransfer/profile_controller"], function (controller) {
                    controller.profile(self.mode, 2, object);
                });
            },
            hypePayment: function (collection) {
                self.mode = 'payment';
                API.hypeTransfer(collection);
            },
            hypeRequest: function (collection) {
                self.mode = 'request';
                API.hypeTransfer(collection);
            },
            contactsList: function (item, quantity) {
                require(["apps/p2p/contacts/list/list_controller"], function (controller) {
                    controller.listEntities(self.mode, item, quantity);
                });
            },
            searchList: function (model, peersCollection, mode) {
                require(["apps/p2p/search/list/list_controller"], function (controller) {
                    controller.listEntities(model, peersCollection, mode);
                });
            },
            addContact: function (newModel) {
                require(["apps/p2p/contacts/profile/profile_controller"], function (controller) {
                    controller.newEntity(newModel);
                });
            },
            editContact: function (entity) {
                require(["apps/p2p/contacts/profile/profile_controller"], function (controller) {
                    controller.editEntity(entity);
                });
            }
        };

        Appersonam.P2pApp.on('show:overlay', function (childView, index) {
            self.panelManager.showOverlay(childView, index);
        });

        Appersonam.P2pApp.on('unset:panelmanager', function () {
            delete self.panelManager;
        });

        Appersonam.P2pApp.on('panelManager:onBackFunction', function (onBackFunction) {
            self.panelManager.onBackFunction = onBackFunction;
        });

        Appersonam.P2pApp.on('contacts:child:list', function (item, quantity) {
            Appersonam.navigate("p2p/friends");
            API.contactsList(item, quantity);
        });

        Appersonam.on('back:button:clicked', function () {
            if (self.panelManager) {
                self.panelManager.backButton();
            }
        });

        Appersonam.P2pApp.on('search:child:list', function (item, quantity) {
            Appersonam.navigate("p2p/friends");
            API.searchList(item, quantity);
        });

        Appersonam.P2pApp.on('close:overlay', function (index) {
            self.panelManager.closeOverlay(index);
        });

        Appersonam.P2pApp.on('new:contact', function (newModel) {
            API.addContact(newModel);
        });

        Appersonam.P2pApp.on('edit:contact', function (entity) {
            API.editContact(entity);
        });

        Appersonam.P2pApp.on('nav:back', function (address, quantity) {
            Appersonam.navigate(address);
            self.panelManager.goTo(null, quantity);
        });

        Appersonam.P2pApp.on('show:main', function (childView, index) {
            if (self.panelManager.currentLevel === 0 && self.disableMenu !== true) {
                self.panelManager.goTo(childView, index);
                setTimeout(function () {
                    Appersonam.NavigationApp.trigger('toggle:menu');
                    setTimeout(function () {
                        Appersonam.NavigationApp.trigger('corner:menu');
                    }, 100);
                }, 500);
            } else {
                self.panelManager.goTo(childView, index);
                setTimeout(function () {
                    Appersonam.trigger('close:loading');
                }, 500);
            }
        });

        Appersonam.P2pApp.on('show:child', function (childView) {
            activitiesController.showChild(childView);
        });
        Appersonam.P2pApp.on('set:active', function (target) {
            activitiesController.setActive(target);
        });

        Appersonam.on('hype:request:new', function (disableMenu) {
            self.disableMenu = disableMenu;
            API.newHypeTransfer('request');
        });

        Appersonam.on('hype:payment:new', function (disableMenu) {
            self.disableMenu = disableMenu;
            API.newHypeTransfer('payment');
        });
        
        Appersonam.P2pApp.on('p2p:search', function (model, peersCollection, mode) {  
            API.searchList(model, peersCollection, mode);
        });

        Appersonam.on('p2p:payment', function (disableMenu) {
            self.disableMenu = disableMenu;
            Appersonam.navigate("p2p/payment");
            API.paymentNavigation();
        });

        Appersonam.on('p2p:request', function (disableMenu) {
            self.disableMenu = disableMenu;
            Appersonam.navigate("p2p/request");
            API.requestNavigation();
        });

        Appersonam.P2pApp.on('simple:payment', function (model) {
            Appersonam.navigate("p2p/simplePayment");
            API.simplePayment(model);
        });

        Appersonam.P2pApp.on('hype:request', function (model) {
            Appersonam.navigate("p2p/hypeRequest");
            API.simpleRequest(model, true);
        });

        Appersonam.P2pApp.on('hype:payment', function (model) {
            Appersonam.navigate("p2p/hypePayment");
            API.simplePayment(model, true);
        });


        Appersonam.P2pApp.on('simple:request', function (object) {
            Appersonam.navigate("p2p/simpleRequest");
            API.simpleRequest(object);
        });

        P2pAppRouter.on('start', function () {
            new P2pAppRouter.Router({
                controller: API
            });
        });
    });
    return Appersonam.P2pAppRouter;
});